import 'package:flutter/material.dart';

import 'widgets/my_saves_body.dart';

class MySavesScreen extends StatelessWidget {
  const MySavesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const MySavesBody();
  }
}
