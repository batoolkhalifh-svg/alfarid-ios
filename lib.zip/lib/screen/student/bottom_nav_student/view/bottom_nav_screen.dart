import 'package:alfarid/screen/student/bottom_nav_student/view/widgets/bottom_nav_body.dart';
import 'package:flutter/material.dart';

class BottomNavScreen extends StatelessWidget {
  const BottomNavScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const BottomNavBody();
  }
}
