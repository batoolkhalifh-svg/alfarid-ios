class BottomNavModel {
  final String title, image;

  BottomNavModel({required this.title, required this.image});
}
