import 'package:flutter/material.dart';

import 'widgets/important_courses_body.dart';

class ImportantCoursesScreen extends StatelessWidget {
  const ImportantCoursesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  ImportantCoursesBody();
  }
}
