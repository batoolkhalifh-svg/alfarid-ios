import 'package:flutter/material.dart';

import 'widgets/my_courses_body.dart';

class MyCoursesScreen extends StatelessWidget {
  const MyCoursesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  MyCoursesBody();
  }
}
