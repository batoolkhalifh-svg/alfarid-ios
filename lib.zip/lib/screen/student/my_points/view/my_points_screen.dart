import 'package:flutter/material.dart';

import 'widgets/my_points_body.dart';

class MyPointsScreen extends StatelessWidget {
  const MyPointsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const MyPointsBody();
  }
}
