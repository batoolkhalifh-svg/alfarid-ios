import 'package:flutter/material.dart';

import 'widgets/lieutenant_body.dart';

class LieutenantScreen extends StatelessWidget {
  const LieutenantScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const LieutenantBody();
  }
}
