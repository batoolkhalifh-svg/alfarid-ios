import 'package:flutter/material.dart';

import 'widgets/excellent_teacher_body.dart';

class ExcellentTeacherScreen extends StatelessWidget {
  const ExcellentTeacherScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  ExcellentTeacherBody();
  }
}
