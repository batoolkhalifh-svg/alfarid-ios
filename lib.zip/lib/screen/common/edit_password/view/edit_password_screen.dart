
import 'package:alfarid/screen/common/edit_password/view/widgets/edit_password_body.dart';
import 'package:flutter/material.dart';


class EditPasswordScreen extends StatelessWidget {
  const EditPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const EditPasswordBody();
  }
}
