
import 'package:alfarid/screen/common/edit_profile/view/widgets/edit_profile_body.dart';
import 'package:flutter/material.dart';


class EditProfileScreen extends StatelessWidget {
  const EditProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const EditProfileBody();
  }
}
