import 'package:flutter/material.dart';

import 'widgets/chat_teacher_body.dart';


class ChatTeacherScreen extends StatelessWidget {
  const ChatTeacherScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  const ChatTeacherBody();
  }
}
