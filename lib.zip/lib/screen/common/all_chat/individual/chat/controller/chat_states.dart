class ChatStates {}

class ChatLoadingState extends ChatStates{}
class ChatFailedState extends ChatStates{}
class ChatSuccessState extends ChatStates{}