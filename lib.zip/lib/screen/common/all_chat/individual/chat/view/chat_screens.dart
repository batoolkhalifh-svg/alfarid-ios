import 'package:alfarid/screen/common/all_chat/individual/chat/view/widgets/chat_body.dart';
import 'package:flutter/material.dart';

class ChatScreens extends StatelessWidget {
  const ChatScreens({super.key});

  @override
  Widget build(BuildContext context) {
    return const ChatBody();
  }
}
