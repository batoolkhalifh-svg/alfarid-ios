import 'package:alfarid/screen/common/help_support/view/widgets/helap_support_body.dart';
import 'package:flutter/material.dart';


class HelpAndSupportScreen extends StatelessWidget {
  const HelpAndSupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const HelpAndSupportBody();
  }
}
