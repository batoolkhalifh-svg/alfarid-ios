import 'package:flutter/material.dart';
import 'widgets/start_live_body.dart';


class StartLiveScreen extends StatelessWidget {
  const StartLiveScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return   const StartLiveBody();
  }
}
