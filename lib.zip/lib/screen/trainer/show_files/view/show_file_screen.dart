import 'package:flutter/material.dart';
import 'widgets/show_file_body.dart';


class ShowFilesScreen extends StatelessWidget {
  const ShowFilesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return   const ShowFilesBody();
  }
}
