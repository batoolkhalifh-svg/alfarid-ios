import 'package:flutter/material.dart';
import 'widgets/subscribe_package_body.dart';


class SubscribePackageScreen extends StatelessWidget {
  const SubscribePackageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const SubscribePackageBody();
  }
}
