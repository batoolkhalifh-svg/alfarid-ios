
import 'package:alfarid/screen/trainer/home_teacher/view/widgets/home_teacher_body.dart';
import 'package:flutter/material.dart';

class TeacherHomeScreen extends StatelessWidget {
  const TeacherHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const HomeTeacherBody();

  }
}
