import 'package:flutter/material.dart';

import 'widgets/bottom_nav_body.dart';

class BottomNavTeacherScreen extends StatelessWidget {
  const BottomNavTeacherScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const BottomNavBody();
  }
}
