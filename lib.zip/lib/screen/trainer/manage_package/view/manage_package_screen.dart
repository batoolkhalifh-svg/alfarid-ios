import 'package:alfarid/screen/trainer/manage_package/view/widgets/manage_package_body.dart';
import 'package:flutter/material.dart';


class ManagePackageScreen extends StatelessWidget {
  const ManagePackageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ManagePackageBody();
  }
}
