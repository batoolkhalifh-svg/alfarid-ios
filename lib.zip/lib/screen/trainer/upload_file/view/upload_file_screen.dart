import 'package:flutter/material.dart';
import 'widgets/upload_file_body.dart';


class UploadFileScreen extends StatelessWidget {
  const UploadFileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return   const UploadFileBody();
  }
}
