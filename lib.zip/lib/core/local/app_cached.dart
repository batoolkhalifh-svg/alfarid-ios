class AppCached {
  static const String token = "token";
  static const String role = "role";
  static const String student = "student";
  static const String teacher = "teacher";
  static const String id = "id";
  static const String phoneKeyCode = "phoneKeyCode";
  static const String name = "name";
  static const String email = "email";
  static const String image = "image";
  static const String isNotify = "isNotify";
  static const String isApple = "isApple";

}